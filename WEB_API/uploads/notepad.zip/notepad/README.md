# No2Pads — A Notepad clone in PyQt

A very simple notepad clone using the QTextEdit widget to handle more or less
everything. Supports file loading, saving and printing.

![No2Pads](screenshot-notepad.jpg)

> If you think this app is neat and want to learn more about
PyQt in general, take a look at my [free PyQt tutorials](https://www.learnpyqt.com)
which cover everything you need to know to start building your own applications with PyQt.